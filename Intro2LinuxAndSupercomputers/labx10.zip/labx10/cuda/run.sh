#!/usr/bin/bash

#matsize=320
#matsize=640
#matsize=960
#matsize=6400
matsize=9600     #size: 1.2 GiB 300 sec on GTX-1080TI
#matsize=12800   #size: 2.1 GiB  300 sec on VT100
#matsize=19200    #size: 4.5 GiB did not complete in 30 minutes.

squeue | grep n.kuznet | grep -s interact
if [ $? -eq 1 ] ; then
    echo "issue:      salloc -p gpu_devel --gpus=1 -N 1 -n 1 -c 1 -t 20 --mem=6G"
else
    /usr/bin/time -p srun -n 1 matmul_GPU -s $matsize &>out_$matsize &
    sleep 5
    sacct -j $SLURM_JOBID
fi




#!/usr/bin/bash

echo "run: . setenv"
module load compilers/gcc-7.3.1
module load compilers/intel
module load gpu/cuda-11.3

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1

which icc

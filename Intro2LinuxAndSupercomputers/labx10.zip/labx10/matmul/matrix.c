/*   
 *   Project "Performance of Matrix Multiplication"
 *   matrix definition
 *
 *   created     author     comments
 *   10/12/2021  I.Zacharov initial release
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <omp.h>
#include <mm_malloc.h>

#include "matmul.h"

#ifndef _OPENMP
#define omp_get_max_threads() 1
#endif

void matlin(long n, matrix_t a)
{
    double *pa = &a[0][0];
    long long tmp;
    //long long base = (long long) &a[0][0];
    long long base = (long long) pa;
    long i,j;
    for(i=0; i<n; i++) {
        printf("\n");
        for(j=0; j<n; j++) {
            //tmp = (long long) &a[i][j] - base; 
            tmp = (long long) &pa[i*n+j] - base; 
            printf(" %ld: %f ",tmp,pa[i*n+j]);
        }
    }
    printf("\n");
}

void matprint ( long n, matrix_t a, matrix_t b, matrix_t c)
{
    long i,j;
    if(n > 10) return;

    printf("matrix: ");
    for(j=0; j<n; j++) printf(" %5d",j);
    printf("\t");
    for(j=0; j<n; j++) printf(" %5d",j);
    printf("\t");
    for(j=0; j<n; j++) printf(" %6d",j);

    printf("\n");

    for(i=0; i<n; i++) {
        printf("abc i: %-3d",i);
        for(j=0; j<n; j++) {
            printf(" %5.3f",a[i][j]);
        }
        printf("\t");
        for(j=0; j<n; j++) {
            printf(" %5.3f",b[i][j]);
        }
        printf("\t");
        for(j=0; j<n; j++) {
            printf(" %6.3f",c[i][j]);
        }
        printf("\n");
    }
    //matlin(n, a);
    //matlin(n, c);
}

void matinit(long n, matrix_t a, matrix_t b, matrix_t c)
{
    struct timespec t1, t2;
    int nomp = omp_get_max_threads();
    
    clock_gettime(CLOCK_MY, &t1);
#pragma omp parallel default(none) firstprivate(n) shared(a,b,c)
    {
        int nomp = 1;
        int iomp = 0;
#ifdef _OPENMP
        nomp = omp_get_num_threads();
        iomp = omp_get_thread_num();
#endif
        struct drand48_data rbuf;
        long   rseed = (1LL + iomp) * GENSEED;
        double dres1;
        long long int i,j;

        srand48_r(rseed, &rbuf);

#pragma omp for
        for(i=0; i<n; i++) {
            for(j=0; j<n; j++) {
                drand48_r(&rbuf, &dres1);
    //            dres1 = (double) ((int) dres1*100)/100.0; //for pres
                a[i][j] = (mmx_t) dres1;
                b[i][j] = (mmx_t) (1.0 - dres1);
                c[i][j] = 0;
            }
        }
    }
    clock_gettime(CLOCK_MY, &t2);
    double dtinit = dseconds(t1,t2);
    fprintf(stderr,"matrix-init--time[sec]: %.1e Threads: %d\n", dtinit,nomp);
}

void matalloc(long n, matrix_t *pa, matrix_t *pb, matrix_t *pc)
{
    struct timespec t1, t2;
    size_t storage_size = n*sizeof(mmx_t *) + n * n * sizeof(mmx_t);
    double dtinit = 0;
    long i;

    clock_gettime(CLOCK_MY, &t1);

    matrix_t a  = _mm_malloc(storage_size, 64);
    matrix_t b  = _mm_malloc(storage_size, 64);
    matrix_t c  = _mm_malloc(storage_size, 64);

    rowmat_t ra  = (rowmat_t ) (a + n);  //row pointer
    rowmat_t rb  = (rowmat_t ) (b + n);  //row pointer
    rowmat_t rc  = (rowmat_t ) (c + n);  //row pointer

    for(i=0; i<n; i++) {
        a[i] = (ra + n * i);
        b[i] = (rb + n * i);
        c[i] = (rc + n * i);
    }

    *pa = a;
    *pb = b;
    *pc = c;

    clock_gettime(CLOCK_MY, &t2);
    dtinit = dseconds(t1,t2);
    fprintf(stderr,"matrix-alloc-time[sec]: %.1e N: %d size: %6.3f MB\n", dtinit, n, 3.0*(double)storage_size/MBYTES);
}

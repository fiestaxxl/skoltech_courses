#!/bin/bash

#SBATCH -p cpu
#SBATCH

export MKL_NUM_THREADS=1
export OMP_NUM_THREADS=1

for x in 1 2 4 8 16 32
do
    export MKL_NUM_THREADS=$x
    export OMP_NUM_THREADS=$x
    #./matmul_C -s 1000
    ./matmul_MKL -s 9600
done

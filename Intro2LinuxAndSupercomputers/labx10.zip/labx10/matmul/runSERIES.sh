#!/usr/bin/bash

time="1:00"
mem=5G
queue=cpu

nodes=1
tasks=1

for ((cpus=1; cpus < 33; cpus*=2))
do
	mincpus=$((cpus+1))
        echo "submit $queue output=matmul_MKL_${cpus}.out -N $nodes -n $tasks -c $cpus --mincpus=$mincpus --mem=$mem --time=$time"

        sbatch -J MKL-${cpus} -p $queue --output=matmul_MKL_${cpus}.out -N $nodes -n $tasks -c $cpus \
                                                --mincpus=$mincpus --mem=$mem --time=$time runMKL.sh
        sleep 5
done
echo END


#!usr/bin/bash

#	Author: Nikita Kuznetsov
#	Date of creation: 23.11.2021, 16:15	version 0.0
#	LabX-5
#
#	Summary: check "Hello, World!" variable global/not global

echo $myvar

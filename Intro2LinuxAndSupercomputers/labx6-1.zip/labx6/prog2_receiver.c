/*	Author: Nikita Kuznetsov
 *	Date of creation: 25.11.2021, 14:00	vqrison 0.0
 *	LabX-6
 *
 *	Summary: this program reads content from shared segmemnt of memory
 *
 *	To compile: gcc -o prog2_receiver prog2_receiver.c
 *	To run: ./prog2_receiver -> prints message
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_KEY		1892	// shm identifier
#define SHM_SIZE	1024	// shm size
# define BUF_SIZE	128

int main()
{
	key_t key;
	size_t size;
	int shmid; // shared_block_id
	void * shared_memory;
	char buff[BUF_SIZE];

	// create shared segment
	if( (shmid = shmget((key_t) SHM_KEY, SHM_SIZE, 0666 | IPC_CREAT)) == -1 )
		{ perror("shmat"); exit(1); }
	
	// attach memory for the segment
	if( (shared_memory = shmat(shmid, NULL, 0)) == (void *) -1 )
		{ perror("shmat"); exit(2); }

	// place shared segment into buffer
	strcpy(buff, shared_memory);
	
	printf("Attached to shmem key %d, id: %x input: %s\n", SHM_KEY, shmid, buff);
	
	// detach segment
	if( (shmdt(shared_memory) == -1) ) { perror("shmdt"); exit(3); }

	// delete segment
	if( (shmctl(shmid, IPC_RMID, NULL)) == -1 ) { perror("shmctl"); exit(4); }
	
	return 0;
}

/*	Author: Nikita Kuznetsov
 *	Date of creation: 25.11.2021, 14:00	vqrison 0.0
 *	LabX-6
 *
 *	Summary: this program creates shared segment in memory and write in it
 *
 *	To compile: gcc -o prog2_sender prog2_sender.c
 *	To run: ./prog2_sender -> input message
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_KEY		1892	// shm identifier
#define SHM_SIZE	1024	// shm size
# define BUF_SIZE	128

int main()
{
	key_t key;
	size_t size;
	int shmid; // shared_block_id
	void * shared_memory;
	char buff[BUF_SIZE];

	// create shared segment
	if( (shmid = shmget((key_t) SHM_KEY, SHM_SIZE, 0666 | IPC_CREAT)) == -1 )
		{ perror("shmat"); exit(1); }
	
	// attach memory for the segment
	if( (shared_memory = shmat(shmid, NULL, 0)) == (void *) -1 )
		{ perror("shmat"); exit(2); }
	
	// write input
	fgets(buff, BUF_SIZE, stdin);

	// copy input in allocated segment
	strcpy(shared_memory, buff);
	
	printf("Attached to shmem key %d, id: %x input: %s\n", SHM_KEY, shmid, buff);
	
	return 0;
}

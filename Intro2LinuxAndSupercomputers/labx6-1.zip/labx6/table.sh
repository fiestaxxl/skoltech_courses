#!/usr/bin/bash

#	Author: Nikita Kuznetsov
#	Date of creation: 25.11.2021 17:00	verison 0.0
#	LabX-6
#
#	Summary: script to make comparison table between mutex, semaphore, atomic

export NUM_THREADS
export N_ITER=100000000
NTRIAL=5

function pthr_mutex () {
	rt=$(/usr/bin/time -p ./prog3e 2>&1 | grep real | cut -d" " -f 2)
	echo $rt
}

function pthr_semaphore () {
	rt=$(/usr/bin/time -p ./prog3g 2>&1 | grep real | cut -d" " -f 2)
	echo $rt
}

function pthr_atomic () {
	rt=$(/usr/bin/time -p ./prog4 2>&1 | grep real | cut -d" " -f 2)
	echo $rt
}

resolution[1]=mutex
resolution[2]=semaphore
resolution[3]=atomic

printf '%-20s: %.1e\n' "number of iterations" $N_ITER
printf '%-20s: %d\n' "number of trials"		 $NTRIAL
printf '%-15s Real time[s] for threads \n' "RACE"
printf '%-17s%-10d%-10d%-10d\n' "resolution" "1" "2" "4"

for y in 1 2 3
do
	printf '%-17s' "${resolution[$y]}"
	for x in 1 2 4
	do
		NUM_THREADS=$x
		mintime=1000000
		
		for (( k=0; k < $NTRIAL; k++ ))
		do
			rt=`pthr_${resolution[$y]}`
			ss=$(echo "$rt < $mintime" | bc)	# use bc for float comparisons
			if [[ $ss -eq 1 ]]
			then
				mintime=$rt
			fi
		done
		printf '%-10f' "$mintime"
	done
	echo ""
done

export -n N_ITER
export -n NUM_THREADS

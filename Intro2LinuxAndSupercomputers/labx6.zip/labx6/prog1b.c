/*	Author: Nikita Kuznetsov
 *	Date of creation: 24.11.2021, 12:15	verison 0.0
 *
 *	LabX-6
 *
 *	Summary: program works as parent recieves data from stdin and child recieves data from parent
 *		 and print in in stdout
 *	
 *	To compile: gcc -o prog1b prog1b.c
 *	To run: ./prog1b
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

main()
{	
	int pfd[2];
	
	if( pipe(pfd) == -1 ) { perror("pipe"); exit(1); }	
	
	int pid = fork();	
	
	if ( pid < 0 ) { perror("fork"); exit(2); }
	else if(pid) close(pfd[0]); // read side, parent writing
	else	     close(pfd[1]); // write side, child reading

	while(1) {
		int inchar;
		int n;

		if( pid < 0 ) { perror("fork"); exit(3); }
		else if(pid) { // parent mode
			inchar = getchar();
			printf("%6d send %c n=%d\n", pid, inchar, n);
			sleep(1);
			if( (n = write(pfd[1], &inchar, sizeof(inchar))) == -1 ) 
				{ perror("write"); exit(4); }
		}
		else {	// child mode
			if( (n = read(pfd[0], &inchar, sizeof(inchar))) == -1)
				{ perror("read"); exit(5); }
			printf("%6d	got %c n=%d\n", pid, inchar, n);
		}
	}
	return 0;
}

#!/usr/bin/bash

NTRIAL=5

for (( k=0; k < $NTRIAL; k++ ))
do
	echo "Iteration: $k"
done
